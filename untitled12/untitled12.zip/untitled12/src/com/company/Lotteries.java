package com.company;

public abstract class Lotteries {

    int digits = 5;

    public abstract void winStatement(String type);

}